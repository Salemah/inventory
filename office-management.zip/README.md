## Coaching Institute Management Software
This is a professional dashboard. using core ui templete. laravel 8
## Packages Used

- Install ``
