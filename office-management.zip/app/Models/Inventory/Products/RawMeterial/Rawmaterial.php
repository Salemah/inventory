<?php

namespace App\Models\Inventory\Products\RawMeterial;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Rawmaterial extends Model
{
    use HasFactory;
    
}
