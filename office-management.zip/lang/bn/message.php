<?php

return [
    'title' => "Il s'agit du titre bn langue espagnole.",
];
