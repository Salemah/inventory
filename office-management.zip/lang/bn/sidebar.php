<?php

return [
    'dashboard' => 'ড্যাশবোর্ড',
    'inventory' => 'ইনভেন্টরি',
    'product' => 'প্রোডাক্ট',
    'project' => 'প্রোজেক্ট',
    'hrm' => 'এইচ আর এম',
    'expense' => 'ব্যয়',
    'revenue' => 'আয়',
    'crm' => 'সি আর এম',
    'account' => 'অ্যাকাউন্ট',
    'investment' => 'ইনভেস্টমেন্ট',
    'employee' => 'কর্মচারী',
    'settings' => 'সেটিংস্‌',
];
