<?php

return [
    'dashboard' => 'Dashboard',
    'inventory' => 'Inventory',
    'product' => 'Product',
    'project' => 'Project',
    'hrm' => 'HRM',
    'expense' => 'Expense',
    'revenue' => 'Revenue',
    'crm' => 'CRM',
    'account' => 'Account',
    'investment' => 'Investment',
    'employee' => 'Employee',
    'settings' => 'Settings',
];
