<?php

return [

    'title' => 'Ceci est le titre fr langue anglaise.',

];
