-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 01, 2022 at 11:46 AM
-- Server version: 5.7.33
-- PHP Version: 7.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wardan_office_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `account_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `user_type` int(11) DEFAULT NULL,
  `transaction_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `transaction_date` date NOT NULL,
  `reference` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `transaction_purpose` tinyint(4) NOT NULL COMMENT '0 = Initial Balance , 1 = Withdraw / 2 = Deposit / 3 = Revenue / 4 = Given Payment / 5 = Expense / 6 =  Fund-Transfer (Cash-In) / 7 =  Fund-Transfer (Cash-Out) / 8 = Cash-In / 9 = Investment',
  `cheque_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_type` tinyint(4) NOT NULL COMMENT '1= Debit / 2= Credit',
  `amount` double NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1 = Active / 0 = Deactivate',
  `access_id` json DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `account_id`, `user_id`, `project_id`, `user_type`, `transaction_title`, `transaction_date`, `reference`, `description`, `transaction_purpose`, `cheque_number`, `transaction_type`, `amount`, `status`, `access_id`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(30, 1, NULL, NULL, NULL, 'Consectetur maiores', '1978-06-28', NULL, 'fdsdfsdfsdfsd', 2, '123456', 2, 25000, 1, '[1]', 1, NULL, '2022-11-01 04:58:34', '2022-11-01 04:58:34', NULL),
(31, 1, NULL, NULL, NULL, 'Exercitationem accus', '2010-03-29', NULL, '', 2, '123456', 2, 10000, 1, '[1]', 1, NULL, '2022-11-01 04:58:52', '2022-11-01 04:58:52', NULL),
(32, 1, NULL, NULL, NULL, 'Rerum qui dolore adi', '2020-06-05', NULL, '', 1, '184', 1, 5000, 1, '[1]', 1, NULL, '2022-11-01 04:59:32', '2022-11-01 04:59:32', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
