-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 01, 2022 at 11:46 AM
-- Server version: 5.7.33
-- PHP Version: 7.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sheanch_crm`
--

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `project_id` int(11) DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  `transaction_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `transaction_date` date NOT NULL,
  `reference` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `transaction_purpose` tinyint(4) NOT NULL COMMENT '0 = Initial Balance , 1 = Withdraw / 2 = Deposit / 3 = Revenue / 4 = Given Payment / 5 = Expense / 6 =  Fund-Transfer (Cash-In) / 7 =  Fund-Transfer (Cash-Out) / 8 = Cash-In /9 = Investment /11 = Profit-Return /10 = Investment-Return /12 = Giving-Loan /13 = Taking-Loan /14 = Return Giving Loan /15 = Return Taking Loan',
  `cheque_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_type` tinyint(4) NOT NULL COMMENT '1= Debit / 2= Credit',
  `amount` double NOT NULL,
  `investment_id` int(11) DEFAULT NULL,
  `loan_id` int(11) DEFAULT NULL,
  `loan_author_id` int(11) DEFAULT NULL,
  `investor_id` int(11) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1 = Active / 0 = Deactivate',
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `project_id`, `account_id`, `transaction_title`, `transaction_date`, `reference`, `description`, `transaction_purpose`, `cheque_number`, `transaction_type`, `amount`, `investment_id`, `loan_id`, `loan_author_id`, `investor_id`, `status`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(11, NULL, 3, 'Initial Balance Deposit', '2022-10-31', NULL, NULL, 0, 'xcvcxvxx', 2, 3534534, NULL, NULL, NULL, NULL, 1, 1, NULL, '2022-10-31 10:42:36', '2022-10-31 10:42:36', NULL),
(12, NULL, 4, 'Initial Balance Deposit', '2022-10-31', NULL, NULL, 0, '257', 2, 4.6855888585782576e33, NULL, NULL, NULL, NULL, 1, 1, NULL, '2022-10-31 11:15:18', '2022-10-31 11:15:18', NULL),
(13, 1, 4, 'investment test', '2022-10-31', NULL, NULL, 1, NULL, 1, 557, NULL, NULL, NULL, NULL, 1, 1, NULL, '2022-10-31 11:15:37', '2022-10-31 11:15:37', NULL),
(14, 1, 0, 'Cash-In', '2022-11-29', NULL, NULL, 8, NULL, 2, 52000, NULL, NULL, NULL, NULL, 1, 1, NULL, '2022-11-01 06:15:34', '2022-11-01 06:15:34', NULL),
(15, 2, 0, 'Cash-In', '2016-01-08', NULL, NULL, 8, NULL, 2, 20000, NULL, NULL, NULL, NULL, 1, 1, NULL, '2022-11-01 06:58:49', '2022-11-01 06:58:49', NULL),
(16, 1, 0, 'Cash-In', '2022-11-21', NULL, NULL, 8, NULL, 2, 1200, NULL, NULL, NULL, NULL, 1, 1, NULL, '2022-11-01 09:21:23', '2022-11-01 09:21:23', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
